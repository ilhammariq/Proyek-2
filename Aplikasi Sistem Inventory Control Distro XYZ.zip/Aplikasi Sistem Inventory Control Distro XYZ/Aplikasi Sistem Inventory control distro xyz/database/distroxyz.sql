-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 21, 2019 at 04:49 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `distroxyz`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbarang`
--

CREATE TABLE `tbarang` (
  `kode_barang` varchar(7) NOT NULL,
  `nama_barang` varchar(20) NOT NULL,
  `warna` varchar(10) NOT NULL,
  `size` varchar(4) NOT NULL,
  `stok` int(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbarang`
--

INSERT INTO `tbarang` (`kode_barang`, `nama_barang`, `warna`, `size`, `stok`) VALUES
('BOB031', 'Orion Black', 'Hitam', 'S', 401),
('BOB0312', 'Baju', 'Pink', 'XL', 0),
('BOG021', 'Orion Green', 'Hijau', 'S', 100),
('BOW013', 'Orion White', 'Putih', 'L', 0),
('V', 'A', 'Pink', 'XXL', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbarangkeluar`
--

CREATE TABLE `tbarangkeluar` (
  `id_barangkeluar` int(4) NOT NULL,
  `no_sdi` varchar(15) NOT NULL,
  `kode_barang` varchar(7) NOT NULL,
  `jumlah_keluar` int(4) NOT NULL,
  `tanggal_keluar` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbarangkeluar`
--

INSERT INTO `tbarangkeluar` (`id_barangkeluar`, `no_sdi`, `kode_barang`, `jumlah_keluar`, `tanggal_keluar`) VALUES
(1, 'BOB031', 'BOB031', 24, '2019-02-20');

--
-- Triggers `tbarangkeluar`
--
DELIMITER $$
CREATE TRIGGER `delete_Stokkeluar` AFTER DELETE ON `tbarangkeluar` FOR EACH ROW BEGIN
	UPDATE tbarang SET tbarang.stok= tbarang.stok + old.jumlah_keluar
    where tbarang.kode_barang = old.kode_barang;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `stok_keluar` AFTER INSERT ON `tbarangkeluar` FOR EACH ROW BEGIN
	UPDATE tbarang SET tbarang.stok=tbarang.stok - new.jumlah_keluar WHERE
    tbarang.kode_barang= new.kode_barang;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbarangmasuk`
--

CREATE TABLE `tbarangmasuk` (
  `id_barangmasuk` int(4) NOT NULL,
  `no_po` varchar(15) NOT NULL,
  `kode_barang` varchar(7) NOT NULL,
  `jumlah_masuk` int(4) NOT NULL,
  `tanggal_masuk` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbarangmasuk`
--

INSERT INTO `tbarangmasuk` (`id_barangmasuk`, `no_po`, `kode_barang`, `jumlah_masuk`, `tanggal_masuk`) VALUES
(8, '1001', 'BOB031', 25, '2019-01-03'),
(9, '11', 'BOB031', 50, '2019-02-01'),
(10, '11', 'BOB031', 50, '2019-02-01'),
(11, '11', 'BOB031', 100, '2019-02-01'),
(12, '1111', 'BOB031', 100, '2019-02-01'),
(13, '100', 'BOB031', 100, '2019-02-01'),
(14, '111', 'BOG021', 100, '2019-02-01');

--
-- Triggers `tbarangmasuk`
--
DELIMITER $$
CREATE TRIGGER `delete_Stokmasuk` AFTER DELETE ON `tbarangmasuk` FOR EACH ROW BEGIN
	UPDATE tbarang SET tbarang.stok = tbarang.stok - old.jumlah_masuk
    where tbarang.kode_barang= old.kode_barang;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `stok_masuk` AFTER INSERT ON `tbarangmasuk` FOR EACH ROW BEGIN
	UPDATE tbarang SET tbarang.stok = tbarang.stok + new.jumlah_masuk
    where tbarang.kode_barang= new.kode_barang;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tuser`
--

CREATE TABLE `tuser` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `tipe` enum('admin','checker') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tuser`
--

INSERT INTO `tuser` (`username`, `password`, `tipe`) VALUES
('admin', 'admin', 'admin'),
('ariq', '123', 'admin'),
('reza', 'reza', 'checker');

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_barangkeluar`
-- (See below for the actual view)
--
CREATE TABLE `view_barangkeluar` (
`id_barangkeluar` int(4)
,`no_sdi` varchar(15)
,`kode_barang` varchar(7)
,`nama_barang` varchar(20)
,`warna` varchar(10)
,`size` varchar(4)
,`jumlah_keluar` int(4)
,`tanggal_keluar` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_barangmasuk`
-- (See below for the actual view)
--
CREATE TABLE `view_barangmasuk` (
`id_barangmasuk` int(4)
,`no_po` varchar(15)
,`kode_barang` varchar(7)
,`nama_barang` varchar(20)
,`warna` varchar(10)
,`size` varchar(4)
,`jumlah_masuk` int(4)
,`tanggal_masuk` date
);

-- --------------------------------------------------------

--
-- Structure for view `view_barangkeluar`
--
DROP TABLE IF EXISTS `view_barangkeluar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_barangkeluar`  AS  select `tbarangkeluar`.`id_barangkeluar` AS `id_barangkeluar`,`tbarangkeluar`.`no_sdi` AS `no_sdi`,`tbarang`.`kode_barang` AS `kode_barang`,`tbarang`.`nama_barang` AS `nama_barang`,`tbarang`.`warna` AS `warna`,`tbarang`.`size` AS `size`,`tbarangkeluar`.`jumlah_keluar` AS `jumlah_keluar`,`tbarangkeluar`.`tanggal_keluar` AS `tanggal_keluar` from (`tbarang` join `tbarangkeluar` on((`tbarang`.`kode_barang` = `tbarangkeluar`.`kode_barang`))) ;

-- --------------------------------------------------------

--
-- Structure for view `view_barangmasuk`
--
DROP TABLE IF EXISTS `view_barangmasuk`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_barangmasuk`  AS  select `tbarangmasuk`.`id_barangmasuk` AS `id_barangmasuk`,`tbarangmasuk`.`no_po` AS `no_po`,`tbarang`.`kode_barang` AS `kode_barang`,`tbarang`.`nama_barang` AS `nama_barang`,`tbarang`.`warna` AS `warna`,`tbarang`.`size` AS `size`,`tbarangmasuk`.`jumlah_masuk` AS `jumlah_masuk`,`tbarangmasuk`.`tanggal_masuk` AS `tanggal_masuk` from (`tbarang` join `tbarangmasuk` on((`tbarang`.`kode_barang` = `tbarangmasuk`.`kode_barang`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbarang`
--
ALTER TABLE `tbarang`
  ADD PRIMARY KEY (`kode_barang`);

--
-- Indexes for table `tbarangkeluar`
--
ALTER TABLE `tbarangkeluar`
  ADD PRIMARY KEY (`id_barangkeluar`),
  ADD KEY `kode_barang` (`kode_barang`);

--
-- Indexes for table `tbarangmasuk`
--
ALTER TABLE `tbarangmasuk`
  ADD PRIMARY KEY (`id_barangmasuk`),
  ADD KEY `kode_barang` (`kode_barang`);

--
-- Indexes for table `tuser`
--
ALTER TABLE `tuser`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbarangkeluar`
--
ALTER TABLE `tbarangkeluar`
  MODIFY `id_barangkeluar` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbarangmasuk`
--
ALTER TABLE `tbarangmasuk`
  MODIFY `id_barangmasuk` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbarangkeluar`
--
ALTER TABLE `tbarangkeluar`
  ADD CONSTRAINT `tbarangkeluar_ibfk_1` FOREIGN KEY (`kode_barang`) REFERENCES `tbarang` (`kode_barang`);

--
-- Constraints for table `tbarangmasuk`
--
ALTER TABLE `tbarangmasuk`
  ADD CONSTRAINT `tbarangmasuk_ibfk_1` FOREIGN KEY (`kode_barang`) REFERENCES `tbarang` (`kode_barang`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
