
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/bootstrap1.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>dist/sweetalert2.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/css_home.css">



<html>
  <head>
    <title>Menu Barang Masuk</title>
  </head>
<body id="LoginForm">
 <br>
  <br>
  <center> <marquee width="50%"> <font color="white"><h1>DATA BARANG MASUK</h1></font></marquee> </center>
    <br>
    <br>
<div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              DATA BARANG </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                   <thead>
                    <tr>
                      <th>No PO</th>
                      <th>Kode Barang</th>
                      <th>Nama Barang</th>
                      <th>Warna</th>
                      <th>Size</th>
                      <th>Jumlah</th>
                      <th>Tanggal</th>
                    
                    </tr>
                  </thead>
<?php
foreach ($record->result() as $view) {
?>
    
    <tr>
      <td><?php echo $view->no_po ?></td> 
      <td><?php echo $view->kode_barang ?></td>
      <td><?php echo $view->nama_barang ?></td>
      <td><?php echo $view->warna ?></td>
      <td><?php echo $view->size ?></td>
      <td><?php echo $view->jumlah_masuk ?></td>
      <td><?php echo $view->tanggal_masuk?></td>
      
    </tr>
<?php } ?>

    <script src="<?php echo base_url();?>assets/vendor/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/datatables/dataTables.bootstrap4.js"></script>
    <script src="<?php echo base_url();?>assets/js/demo/datatables-demo.js"></script>

</table>

</table>
</body>
</html>