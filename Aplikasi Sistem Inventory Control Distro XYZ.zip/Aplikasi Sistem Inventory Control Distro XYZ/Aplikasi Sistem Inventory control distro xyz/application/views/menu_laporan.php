<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/bootstrap1.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>dist/sweetalert2.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/css_home.css">
<script src="<?php echo base_url()?>js/highcharts.js"></script>
<script src="<?php echo base_url()?>js/exporting.js"></script>
<script src="<?php echo base_url()?>js/export-data.js"></script>

<br>
  <br>
  <center> <marquee width="50%"> <font color="white"><h1>DATA LAPORAN</h1></font></marquee> </center>
  <br>
<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>

<div class="row">
	<div class="col-lg-12">
		<div id="data_barang"></div>
	</div>
</div>

<?php
$kode_brg = array();
$stok = array();
foreach ($record->result() as $view) {
    $kode_brg[] = $view->kode_barang;
    $stok[] = intval($view->stok);

}

?>

<script>
Highcharts.chart('container', {
    chart: {
        type: 'area'
    },
    title: {
        text: ' Jumlah Stok Barang'
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        categories: <?=json_encode($kode_brg);?>,
        tickmarkPlacement: 'on',
        title: {
            text: 'Kode Barang'
        }
    },
    yAxis: {
        title: {
            text: 'Jumlah Satuan'
        },
        labels: {
            formatter: function () {
                return this.value;
            }
        }
    },
    tooltip: {
        split: true,
        valueSuffix: ''
    },
    plotOptions: {
        area: {
            stacking: 'normal',
            lineColor: '#666666',
            lineWidth: 1,
            marker: {
                lineWidth: 1,
                lineColor: '#666666'
            }
        }
    },
    series: [{
        name: 'Jumlah Stok',
        data: <?=json_encode($stok);?>
    }]
});
</script>



