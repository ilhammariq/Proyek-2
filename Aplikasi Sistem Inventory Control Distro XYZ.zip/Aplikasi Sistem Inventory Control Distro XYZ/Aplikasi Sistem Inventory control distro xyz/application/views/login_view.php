<html>
  <head>

<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/bootstrap1.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>dist/sweetalert2.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/css_login.css">
  </head>
<body>

<div class="container">
<div class="login-form">
<div class="main-div">
    <div class="panel">
   <h2>Login</h2>
   <p>Silahkan masukan username dan password</p>
   </div>
    
   		
        <div class="form-group">

<form action="<?php echo site_url('login/ceklogin')?>" method="post">

            <?php
                $info = $this->session->flashdata('message');
                if(!empty($info)){
                    echo $info;
                }
            ?>
            
            

            <input type="text" name="username" class="form-control"   placeholder="Username" required>

        </div>

        <div class="form-group">

            <input type="password" name="password" class="form-control"  placeholder="Password">

        </div>
        <div class="sign_up">
        <a>Belum Punya Akun?</a> <a href ="<?php echo site_url('login/sign_up1')?>">Sign Up</a>
        <br>

</div>
       <button  type="submit" class="btn btn-primary" name="submit" >Login</button>
    
        <button type="reset" class="btn btn-primary">Clear</button>

</form>
    </div>
</div></div>
</body>
</html>


