<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/bootstrap1.min.css">
<link href="<?php echo base_url();?>assets/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/bootstrap1.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>dist/sweetalert2.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/css_home.css">

<html>
<head>
  <title>Laporan Barang Masuk</title>
    
    <link rel="stylesheet" href="<?php echo base_url('assets/jquery-ui/jquery-ui.min.css'); ?>" /> 
    <script src="<?php echo base_url('assets/jquery.min.js'); ?>"></script> 
</head>
<body>
<div class="container">
<div class="login-form">
<div class="main-div">
    <div class="panel">

    <h3>Data Transaksi Barang Masuk</h3><hr>
    <form method="POST" action="laporan_barangmasuk/print">
      <div class="form-group">
            <input type="date" name="tgl1" class="form-control" id="tgl1"  required>
        </div>
        <div class="form-group">
        
            <input type="date" name="tgl2"class="form-control"  id="tgl2" required>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Cetak</button>
    </form>
    <hr />
    
    </div>
</div>
</div>
   <div class="card mb-3">
  
            <div class="card-header">
              <i class="fas fa-table"></i>
              DATA BARANG </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                   <thead>
                    <tr>
                      <th>Tanggal</th>
                      <th>No. PO</th>
                      <th>Kode Barang</th>
                      <th>Nama Barang</th>
                      <th>Warna</th>
                      <th>Size</th>
                      <th>Jumlah</th>
                    </tr>
                  </thead>
              </div>
    <?php
    if( ! empty($transaksi)){
      $no = 1;
      foreach($transaksi as $data){
            $tgl = date('d-m-Y', strtotime($data->tanggal_masuk));
            
        echo "<tr>";
        echo "<td>".$tgl."</td>";
        echo "<td>".$data->no_po."</td>";
        echo "<td>".$data->kode_barang."</td>";
        echo "<td>".$data->nama_barang."</td>";
        echo "<td>".$data->warna."</td>";
        echo "<td>".$data->size."</td>";
        echo "<td>".$data->jumlah_masuk."</td>";
        echo "</tr>";
        $no++;
      }
    }
    ?>
    
    <script src="<?php echo base_url('assets/jquery-ui/jquery-ui.min.js'); ?>"></script> 
</table>
</body>
</html>