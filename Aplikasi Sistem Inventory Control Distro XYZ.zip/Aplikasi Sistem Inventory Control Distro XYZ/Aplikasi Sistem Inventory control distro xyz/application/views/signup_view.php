<html>
  <head>

<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/bootstrap1.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>dist/sweetalert2.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/login1.css">
  </head>
<body>

<div class="container">
<div class="login-form">
<div class="main-div">
    <div class="panel">
   <h2>Sign Up</h2>
   <p>Silahkan masukan Data</p>
   </div>
    
   <form action="<?php echo site_url('login/sign_up')?>" method="post">
   <?php
                $info = $this->session->flashdata('message');
                if(!empty($info)){
                    echo $info;
                }
            ?>

<?php
                $info = $this->session->flashdata('sign');
                if(!empty($info)){
                    echo $info;
                }
            ?>
           
        <div class="form-group">

            <input type="text" name="username"class="form-control"  id="username" placeholder="Username" required>

        </div>

        <div class="form-group">

            <input type="password" name="password" class="form-control" id="password" placeholder="Password">

        </div>
            
            <div class="tipe">
                
            <input type="radio" class="input-control" name="tipe" value="admin" required>Admin
            <input type="radio" class="input-control" name="tipe" value="checker" required>Checker
            </div>

        <div class="sign_up">
        <a>Sudah Punya Akun?</a> <a href="<?php echo site_url('login/index')?>">Login</a>
        <br>

</div>
       <button  type="submit" class="btn btn-primary" name="submit" >Sign Up</button>
    <script src="<?php echo base_url()?>dist/sweetalert2.min.js"></script>
        <script> 
 				
 			     	
        </script>
        <button type="reset" class="btn btn-primary">Clear</button>

</form>
    </div>
</div></div>
</body>
</html>


