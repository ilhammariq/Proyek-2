<?php  
?>

<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/bootstrap2.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>dist/sweetalert2.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/css_home.css">
  



<html>
  <head>
    <title>Menu Barang</title>
  </head>
<body id="LoginForm">
<br>
  <br>
  <center> <marquee width="50%"> <font color="white"><h1>DATA BARANG</h1></font></marquee> </center>
    <br>
    <br>

<div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              DATA BARANG </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                   <thead>
                    <tr>
                      <th>No</th>
                      <th>Kode Barang</th>
                      <th>Nama Barang</th>
                      <th>Warna</th>
                      <th>Size</th>
                      <th>Stok</th>
                    </tr>
                  </thead>
<?php
$no=1;
foreach ($record->result() as $view) {
?>
    <tr>
      <td><?php echo $no ?></td> 
      <td><?php echo $view->kode_barang ?></td>
      <td><?php echo $view->nama_barang ?></td>
      <td><?php echo $view->warna ?></td>
      <td><?php echo $view->size ?></td>
      <td><?php echo $view->stok ?></td>
    </tr>
<?php $no++; } ?>


    <script src="<?php echo base_url();?>assets/vendor/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/datatables/dataTables.bootstrap4.js"></script>
    <script src="<?php echo base_url();?>assets/js/demo/datatables-demo.js"></script>

</table>
</body>
</html>