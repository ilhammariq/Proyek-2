<?php
  echo form_open('Barang_keluar/simpan_barangkeluar')   
?>

<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/bootstrap1.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>dist/sweetalert2.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/css_home.css">
  
<!------ Include the above in your HEAD tag ---------->


<html>
  <head>
    <title>Menu Barang Keluar</title>
  </head>
<body id="LoginForm">
<br>
  <br>
  <center> <marquee width="50%"> <font color="white"><h1>DATA BARANG KELUAR</h1></font></marquee> </center>
<div class="container">
<div class="login-form">
<div class="main-div">
    <div class="panel">
   <h2>Form Barang Keluar</h2>
  
   </div>
            <?php
                $info = $this->session->flashdata('stok');
                if(!empty($info)){
                    echo $info;
                }
            ?>
        <div class="form-group">
            <input type="text" name="no_sdi" class="form-control" id="no_sdi" placeholder="No Surat" required>
        </div>
        <div class="form-group">
        <select name="kode_barang" class="form-control" id="kode_barang" required>
        <?php
        foreach ($record1->result() as $v){
        ?>
            <option value="<?php echo $v->kode_barang ?>"><?php echo $v->kode_barang ?></option><?php } ?>
            </select>
        </div>
        <div class="form-group">
            <input type="text" name="jumlah_keluar" class="form-control" id="jumlah_keluar" placeholder="Jumlah" required>
        </div>
        <div class="form-group">
            <input type="date" name="tanggal_keluar" class="form-control" id="tanggal_keluar" placeholder="Tanggal">
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Simpan</button>
        <button type="reset" class="btn btn-primary">Clear</button>
</div>
</div>
</div>

<div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              DATA BARANG </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                   <thead>
                    <tr>
                    <th>No</th>
                      <th>No Surat</th>
                      <th>Kode Barang</th>
                      <th>Nama Barang</th>
                      <th>Warna</th>
                      <th>Size</th>
                      <th>Jumlah</th>
                      <th>Tanggal</th>
                      <th>Aksi</th>
                    </tr>
                  </thead>
<?php
$no=1;
foreach ($record->result() as $view) {
?>
    <tr>
      <td><?php echo $no ?></td> 
      <td><?php echo $view->no_sdi ?></td> 
      <td><?php echo $view->kode_barang ?></td>
      <td><?php echo $view->nama_barang ?></td>
      <td><?php echo $view->warna ?></td>
      <td><?php echo $view->size ?></td>
      <td><?php echo $view->jumlah_keluar ?></td>
      <td><?php echo $view->tanggal_keluar?></td>
      <td><?php echo anchor('Barang_keluar/delete/'.$view->id_barangkeluar, 'Delete') ?></td>
    </tr>
<?php $no++; } ?>



    <script src="<?php echo base_url();?>assets/vendor/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/datatables/dataTables.bootstrap4.js"></script>
    <script src="<?php echo base_url();?>assets/js/demo/datatables-demo.js"></script>

</table>
</body>
</html>