<?php
  echo form_open('Barang/simpan_barang')   
?>

<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/bootstrap1.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>dist/sweetalert2.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/css_home.css">
  



<html>
  <head>
    <title>Menu Barang</title>
  </head>
<body id="LoginForm">
<br>
  <br>
  <center> <marquee width="50%"> <font color="white"><h1>DATA BARANG</h1></font></marquee> </center>
    
<div class="container">
<div class="login-form">
<div class="main-div">
    <div class="panel">
   <h2>Form Barang</h2>
   </div>
   <?php
                $info = $this->session->flashdata('message');
                if(!empty($info)){
                    echo $info;
                }
            ?>
      
        <div class="form-group">
            <input type="text" name="kode_barang"class="form-control"  id="kode_barang" placeholder="Kode Barang" required>
        </div>
        <div class="form-group">
            <input type="text" name="nama_barang" class="form-control" id="nama_barang" placeholder="Nama Barang" required>
        </div>
        <div class="form-group">
            <input type="text" name="warna" class="form-control" id="warna" placeholder="Warna" required>
        </div><div class="form-group">
         
            <select name="size" class="form-control" id="size" required>
            <option value="">Size</option>
            <option value="S">S</option>
            <option value="M">M</option>
            <option value="L">L</option>
            <option value="XL">XL</option>
            <option value="XXL">XXL</option>
            <option value="XXXL">XXXL</option>
            </select>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Simpan</button>
        <button type="reset" class="btn btn-primary">Clear</button>
</div>
</div>
</div>

<div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
              DATA BARANG </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                   <thead>
                    <tr>
                      <th>No</th>
                      <th>Kode Barang</th>
                      <th>Nama Barang</th>
                      <th>Warna</th>
                      <th>Size</th>
                      <th>Stok</th>
                      <th>Aksi</th>
                    </tr>
                  </thead>
<?php
$no=1;
foreach ($record->result() as $view) {
?>
    <tr>
      <td><?php echo $no ?></td> 
      <td><?php echo $view->kode_barang ?></td>
      <td><?php echo $view->nama_barang ?></td>
      <td><?php echo $view->warna ?></td>
      <td><?php echo $view->size ?></td>
      <td><?php echo $view->stok ?></td>
      <td><?php echo anchor('Barang/edit/'.$view->kode_barang, 'Edit') ?></td>
    </tr>
<?php $no++; } ?>


<script src="<?php echo base_url();?>assets/vendor/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/datatables/dataTables.bootstrap4.js"></script>
    <script src="<?php echo base_url();?>assets/js/demo/datatables-demo.js"></script>


</table>
</body>
</html>