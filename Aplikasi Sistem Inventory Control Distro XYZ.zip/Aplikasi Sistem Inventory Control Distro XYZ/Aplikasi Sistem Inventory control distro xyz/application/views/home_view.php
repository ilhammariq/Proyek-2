

    <script src="<?php echo base_url()?>js/jquery.js"></script>
<script type="text/javascript" src='<?php echo base_url()?>js/bootstrap.min.js'></script>
<link rel="stylesheet" href="<?php echo base_url()?>css/bootstrap.css" />

<nav class="navbar navbar-expand-lg navbar-light bg-light">

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url()?>index.php/menu">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url()?>index.php/Barang_masuk">Barang Masuk</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="<?php echo base_url()?>index.php/Barang_keluar">Barang Keluar</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url()?>index.php/Barang">Barang</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Laporan
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="<?php echo base_url()?>index.php/laporan">Laporan</a>
          <a class="dropdown-item" href="<?php echo base_url()?>index.php/laporan_barangmasuk">Laporan Barang Masuk</a>
          <a class="dropdown-item" href="<?php echo base_url()?>index.php/laporan_barangkeluar">Laporan Barang Keluar</a>
        </div>
      </li>
      
      
    </ul>


    <a class="nav-link" href="<?php echo base_url()?>index.php/login/logout">Logout</a>
    
  </div>
</nav>