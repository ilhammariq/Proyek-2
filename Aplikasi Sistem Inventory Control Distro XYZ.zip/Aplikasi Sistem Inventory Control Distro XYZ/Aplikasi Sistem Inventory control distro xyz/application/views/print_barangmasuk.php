<html>
<head>
  <title>Cetak PDF</title>
  <style>
    table {
      border-collapse:collapse;
      table-layout:fixed;width: 500px;
    }
    table td {
      word-wrap:break-word;
      width: 20%;
    }
  </style>
</head>
<body>
    <b><?php echo $ket; ?></b><br /><br />
    
  <table border="1" cellpadding="8">
  <tr>
        <th>Tanggal</th>
        <th>No PO</th>
        <th>Kode Barang</th>
        <th>Nama Barang</th>
        <th>Warna</th>
        <th>Size</th>
        <th>Jumlah</th>
  </tr>
    <?php
    if( ! empty($transaksi)){
      foreach($transaksi as $data){
            $tgl = date('d-m-Y', strtotime($data->tanggal_masuk));
        echo "<tr>";
        echo "<td>".$tgl."</td>";
        echo "<td>".$data->no_po."</td>";
        echo "<td>".$data->kode_barang."</td>";
        echo "<td>".$data->nama_barang."</td>";
        echo "<td>".$data->warna."</td>";
        echo "<td>".$data->size."</td>";
        echo "<td>".$data->jumlah_masuk."</td>";
        echo "</tr>";
      }
    }
    ?>
  </table>
</body>
</htm