<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class c_menu extends CI_Controller {

	function __construct(){
		parent::__construct();

		$this->load->model('model_menu');
	}
	function index()
	{
		$data['record'] = $this->model_menu->tampil_barang();
		
		$this->load->view('c_home_view'); 
		$this->load->view('c_menu_view', $data);
		$this->load->model('model_login');
		$this->model_login->keamanan();		
		
    }

}