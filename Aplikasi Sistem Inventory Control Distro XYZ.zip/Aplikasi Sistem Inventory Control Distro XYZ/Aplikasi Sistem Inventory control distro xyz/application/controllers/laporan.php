<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class laporan extends CI_Controller {

	function __construct(){
		parent::__construct();

		$this->load->model('model_laporan');
	}

	public function index()
	{
		$data['record'] = $this->model_laporan->tampil_barang();
		$this->load->view('home_view', $data);
		$this->load->view('menu_laporan');
    }

}