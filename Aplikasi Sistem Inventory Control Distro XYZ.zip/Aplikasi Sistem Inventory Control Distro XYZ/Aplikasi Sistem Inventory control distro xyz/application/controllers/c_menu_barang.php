<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class c_menu_barang extends CI_Controller {

	function __construct(){
		parent::__construct();

		$this->load->model('model_barang');
	}

	  function index(){
	 	$data['record'] = $this->model_barang->tampil_barang();
		 $this->load->view('c_home_view'); 
		 $this->load->view('c_menu_barang', $data);
		 $this->load->model('model_login');
		$this->model_login->keamanan();
	
     }
    }