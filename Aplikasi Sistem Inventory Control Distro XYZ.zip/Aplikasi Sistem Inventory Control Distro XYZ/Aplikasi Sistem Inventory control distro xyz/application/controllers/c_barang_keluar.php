<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class c_barang_keluar extends CI_Controller {

	function __construct(){
		parent::__construct();

		$this->load->model('model_barangKeluar');
	}

	  function index(){
	 	$data['record'] = $this->model_barangKeluar->tampil_barangkeluar();
		 $this->load->view('c_home_view'); 
		 $this->load->view('c_menu_barangKeluar', $data);
		 $this->load->model('model_login');
		$this->model_login->keamanan();
		
    }
}
