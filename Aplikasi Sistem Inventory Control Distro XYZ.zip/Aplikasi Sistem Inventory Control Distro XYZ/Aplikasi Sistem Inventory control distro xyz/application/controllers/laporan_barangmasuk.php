<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class laporan_barangmasuk extends CI_Controller {
  
  public function __construct(){
    parent::__construct();
    
    $this->load->model('model_laporan_barangmasuk');
  }
  
  public function index(){
    $ket = 'Semua Data Transaksi';      
    $transaksi = $this->model_laporan_barangmasuk->view_all(); 
    $data['ket'] = $ket;
    $data['transaksi'] = $transaksi;
   
    $this->load->view('home_view');
    $this->load->view('view_laporanbarangmasuk', $data);
    

  }
  public function print(){
    $this->load->model('model_laporan_barangmasuk');
    $this->model_laporan_barangmasuk->cetak();
  }
  
}
