<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class c_barang_masuk extends CI_Controller {

	function __construct(){
		parent::__construct();

		$this->load->model('model_barangMasuk');
	}

	  function index(){
		 $data['record'] = $this->model_barangMasuk->tampil_barangmasuk();
		$this->load->view('c_home_view'); 
		$this->load->view('c_menu_barangMasuk', $data);
		$this->load->model('model_login');
		$this->model_login->keamanan();
		
    }
}