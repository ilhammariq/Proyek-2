<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class laporan_barangkeluar extends CI_Controller {
  
  public function __construct(){
    parent::__construct();
    
    $this->load->model('model_laporan_barangkeluar');
  }
  
  public function index(){
    $ket = 'Semua Data Transaksi';      
    $transaksi = $this->model_laporan_barangkeluar->view_all(); 
    $data['ket'] = $ket;
    $data['transaksi'] = $transaksi;
   
    $this->load->view('home_view');
    $this->load->view('view_laporanbarangkeluar', $data);
    
  }
  
 
  public function print(){
    $this->load->model('model_laporan_barangkeluar');
    $this->model_laporan_barangkeluar->cetak();
}
}
