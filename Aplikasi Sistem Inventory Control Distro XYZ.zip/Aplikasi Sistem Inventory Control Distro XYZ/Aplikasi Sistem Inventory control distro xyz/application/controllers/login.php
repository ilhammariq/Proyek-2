
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class login extends CI_Controller {

    
	public function index()
	{
        $this->load->model('model_login');
		$this->model_login->keamanan1();
		$this->load->view('login_view');
    }
    public function sign_up1()
    {
        $this->load->model('model_login');
		$this->model_login->keamanan1();
        $this->load->view('signup_view');
    }
    public function ceklogin()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $this->load->model('model_login');
        $this->model_login->ambil_login($username,$password);
    }
    public function logout()
    {
        $this->session->set_userdata('username', FALSE);
        $this->session->sess_destroy();
        redirect('login');  
    }

    public function sign_up(){
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $tipe = $this->input->post('tipe');
        $this->load->model('model_login'); 
        $this->model_login->set_signup($username,$password,$tipe);
        redirect('login/sign_up1');
    
    }	
   
}
