<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barang_masuk extends CI_Controller {

	function __construct(){
		parent::__construct();

		$this->load->model('model_barangMasuk');
	}

	  function index(){
		 $data['record'] = $this->model_barangMasuk->tampil_barangmasuk();
		 $data['record1'] = $this->model_barangMasuk->tampil_barang();
		$this->load->view('home_view'); 
		$this->load->view('menu_barangMasuk', $data);
		$this->load->model('model_login');
		$this->model_login->keamanan();
		
	}

	function simpan_barangmasuk(){
		$data = array("no_po"=>$this->input->post('no_po'),
		"kode_barang"=>$this->input->post('kode_barang'),  
		"jumlah_masuk"=>$this->input->post('jumlah_masuk'), 
		"tanggal_masuk"=>$this->input->post('tanggal_masuk'));
        $this->load->model('model_barangMasuk'); 
		$this->model_barangMasuk->simpan_barangmasuk($data);
		redirect("Barang_masuk");

	}

	function delete($id_barangmasuk){
		$this->model_barangMasuk->delete($id_barangmasuk);
		redirect("Barang_masuk");
	}


}
