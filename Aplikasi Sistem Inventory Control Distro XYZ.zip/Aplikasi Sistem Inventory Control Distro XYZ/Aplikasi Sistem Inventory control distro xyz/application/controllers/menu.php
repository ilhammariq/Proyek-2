
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class menu extends CI_Controller {

	function __construct(){
		parent::__construct();

		$this->load->model('model_menu');
	}
	function index()
	{
		$data['record'] = $this->model_menu->tampil_barang();
		$this->load->view('home_view'); 
		$this->load->view('menu_view', $data);
		$this->load->model('model_login');
		$this->model_login->keamanan();		
		
    }

}
?>

