<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barang_keluar extends CI_Controller {

	function __construct(){
		parent::__construct();

		$this->load->model('model_barangKeluar');
	}

	  function index(){
		 $data['record'] = $this->model_barangKeluar->tampil_barangkeluar();
		 $data['record1'] = $this->model_barangKeluar->tampil_barang();
		 $this->load->view('home_view'); 
		 $this->load->view('menu_barangKeluar', $data);
		 $this->load->model('model_login');
		$this->model_login->keamanan();
		
	}

	function simpan_barangkeluar(){
		$kode_barang = $this->input->post('kode_barang');
		$jumlah_keluar=$this->input->post('jumlah_keluar');
		$data = array("no_sdi"=>$this->input->post('no_sdi'), 
		"kode_barang"=>$this->input->post('kode_barang'), 
		"jumlah_keluar"=>$this->input->post('jumlah_keluar'), 
		"tanggal_keluar"=>$this->input->post('tanggal_keluar'));
        $this->load->model('model_barangKeluar'); 
		$this->model_barangKeluar->simpan_barangkeluar($kode_barang,$data,$jumlah_keluar);
		redirect("Barang_keluar");

	}

	function delete($id_barangkeluar){
		$this->model_barangKeluar->delete($id_barangkeluar);
		redirect("Barang_keluar");
	}


}
