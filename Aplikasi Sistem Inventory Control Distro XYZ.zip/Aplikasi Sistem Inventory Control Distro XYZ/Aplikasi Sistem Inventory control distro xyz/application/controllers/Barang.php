<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barang extends CI_Controller {

	function __construct(){
		parent::__construct();

		$this->load->model('model_barang');
	}

	  function index(){
	 	$data['record'] = $this->model_barang->tampil_barang();
		 $this->load->view('home_view'); 
		 $this->load->view('menu_barang', $data);
		 $this->load->model('model_login');
		$this->model_login->keamanan();
	
	 }

	function simpan_barang(){
		$kode_barang = $this->input->post('kode_barang');
		$data = array("kode_barang"=>$this->input->post('kode_barang'),
		"nama_barang"=>$this->input->post('nama_barang'), 
		"warna"=>$this->input->post('warna'), 
		"size"=>$this->input->post('size'));
		$this->model_barang->simpan_barang($data,$kode_barang);
		redirect("Barang");

	}


	function edit($kode_barang){
		$data['detail'] = $this->model_barang->get_detail($kode_barang);
		$data['record'] = $this->model_barang->tampil_barang();
		$this->load->view('home_view');
		$this->load->view('edit_data', $data);

		if(isset($_POST['submit'])){
			$data = array("kode_barang"=>$this->input->post('kode_barang'), 
			"nama_barang"=>$this->input->post('nama_barang'), 
			"warna"=>$this->input->post('warna'), 
			"size"=>$this->input->post('size'));
			$this->model_barang->edit($kode_barang,$data);
			redirect("Barang");
		}
	}



}
