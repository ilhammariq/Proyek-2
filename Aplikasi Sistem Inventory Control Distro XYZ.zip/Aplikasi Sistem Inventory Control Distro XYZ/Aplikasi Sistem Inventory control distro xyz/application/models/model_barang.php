<?php

	class model_barang extends CI_Model{

		function tampil_barang(){
			return $this->db->get('tbarang');		
		}

		function simpan_barang($data,$kode_barang){
			$cek_kodebarang = $this->db->get_where('tbarang', array('kode_barang' => $kode_barang));
			if ($cek_kodebarang->num_rows()>0){
			$this->session->set_flashdata('message','Kode Barang yang anda masukan sudah terdaftar!');
            redirect('Barang');
		}else{
			$this->db->insert('tbarang', $data);
            
		}
	}


		function get_detail($kode_barang){
			$this->db->where('kode_barang', $kode_barang);
			return $this->db->get_where('tbarang');
		}

		function edit($kode_barang,$data){
			$this->db->where('kode_barang', $kode_barang);
			$this->db->update('tbarang',$data);
			
		}
		
	}	
?>