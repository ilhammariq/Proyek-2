<?php

	class model_laporan extends CI_Model{

		function tampil_barang(){
			return $this->db->get('tbarang');	
		}
	}
?>