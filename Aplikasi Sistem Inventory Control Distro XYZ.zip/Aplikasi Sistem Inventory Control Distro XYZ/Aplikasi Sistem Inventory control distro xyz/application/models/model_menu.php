<?php

	class model_menu extends CI_Model{

		function tampil_barang(){
            return $this->db->query("SELECT * from tbarang where stok<3 ");
            		
        }
    }
?>
