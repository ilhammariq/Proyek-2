<?php

	class model_barangMasuk extends CI_Model{

		function tampil_barangmasuk(){
			return $this->db->get('view_barangmasuk');		
        }
        function tampil_barang(){
			return $this->db->get('tbarang');		
        }

        
        function simpan_barangmasuk($data){
			$this->db->insert('tbarangmasuk', $data);
            redirect('Barang_masuk');   
        }

		function delete($id_barangmasuk){
			$this->db->where('id_barangmasuk', $id_barangmasuk);
			$this->db->delete('tbarangmasuk');
		} 

		
    }	

?>