
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class model_login extends CI_Model {

   
    public function ambil_login($username,$password)
    {
        $this->db->where('username',$username);
        $this->db->where('password',$password);
        $query = $this->db->get('tuser');
        if($query->num_rows()>0){
            foreach ($query->result() as $row);
            $this->session->set_userdata('username', $row->username);
            $this->session->set_userdata('tipe', $row->tipe);

            if($this->session->userdata('tipe') == "admin"){
                redirect('menu');
            }elseif($this->session->userdata('tipe') == "checker"){
                redirect('c_menu');
            }
        }
        else{
            $this->session->set_flashdata('message','Username atau Password yang anda masukan salah!');
            redirect('login');
        }
        
    }
    public function keamanan(){
        $username = $this->session->userdata('username');
        if(empty($username)){
            $this->session->sess_destroy();
            redirect('login');
        }
    }
    public function keamanan1(){
        $username = $this->session->userdata('username');
        if(!empty($username)){
            redirect('menu');
        }
    }

    public function set_signup($username,$password,$tipe){
        $cek_username = $this->db->get_where('tuser', array('username' => $username));
        if ($cek_username->num_rows()>0){
            $this->session->set_flashdata('message','Username yang anda masukan sudah digunakan!');
            redirect('login/sign_up1');
         
        }else{
            $this->db->insert('tuser', array('username' => $username,'password' => $password,'tipe' => $tipe));
            $this->session->set_flashdata('sign','Anda Telah Berhasil Signup');
            redirect('login/sign_up1');
            
        }
    }
			
    
}
