<?php

	class model_barangKeluar extends CI_Model{

		function tampil_barangkeluar(){
			return $this->db->get('view_barangkeluar');		
        }
        function tampil_barang(){
			return $this->db->get('tbarang');		
        }
        
        function simpan_barangkeluar($kode_barang,$data,$jumlah_keluar){
            $a = $this->db->query("select stok from tbarang where kode_barang = '".$kode_barang."'");
            foreach($a->result_array() as $d);
            if($jumlah_keluar < $d['stok'])
            {
              $this->db->insert('tbarangkeluar', $data);
             }else{
             $this->session->set_flashdata('stok','Stok yang anda masukan melebihi Stok yang ada!');
            redirect('Barang_keluar'); 
              }
    }
    
         function delete($id_barangkeluar){
            $this->db->where('id_barangkeluar', $id_barangkeluar);
            $this->db->delete('tbarangkeluar');
          } 

		
    }	

?>