<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class model_laporan_barangkeluar extends CI_Model {
    
  public function view_by_month($bulan){
        $this->db->where('MONTH(tanggal_keluar)', $bulan);
    return $this->db->get('view_barangkeluar')->result(); 
  }
   public function view_by_periode($tgl1, $tgl2){
        $query = $this->db->query("SELECT * FROM view_barangkeluar WHERE tanggal_keluar BETWEEN '$tgl1' AND '$tgl2'");
        return $query->result();
        
  }

  public function view_all(){
    return $this->db->get('view_barangkeluar')->result(); 
  }
    
    public function cetak(){
      if(isset($_POST['submit'])){ 
            
            $tgl1 = $this->input->post('tgl1');
            $tglp = date('d-m-Y', strtotime($tgl1));
            $tgl2 = $this->input->post('tgl2');
            $tglk = date('d-m-Y', strtotime($tgl2));
            $ket = 'Data Barang Keluar '.$tglp.' sampai '.$tglk.'';
            $transaksi = $this->model_laporan_barangkeluar->view_by_periode($tgl1,$tgl2);
                
      }else{ 
          $ket = 'Semua Data Transaksi';
          $transaksi = $this->model_laporan_barangkeluar->view_all(); 
      }
      
      $data['ket'] = $ket;
      $data['transaksi'] = $transaksi;
      
  ob_start();
  $this->load->view('print_barangkeluar', $data);
  $html = ob_get_contents();
      ob_end_clean();
      
      require_once('./assets/html2pdf/html2pdf.class.php');
  $pdf = new HTML2PDF('P','A4','en');
  $pdf->WriteHTML($html);
  $pdf->Output('Data Laporan Barang Keluar.pdf', 'D');
}
}