<?php

class Menu_lib{
    public function __construct(){
        $this->CI =& get_instance();
    }
    public function menu_navigation() {
        $menu = array(
                array('text' => 'Home', 'url' => ''),
                array('text' => 'Page 1', 'url' => 'page1'),
                array('text' => 'Page 2', 'url' => 'page2'),
                array('text' => 'Page 3', 'url' => 'page3'));

                $page2 = $this->CI->uri->segment(2);

                $html= '<ul>';
                foreach ($menu as $data){
                    $menu_active = '';
                    if ($page2  == $data['url']){
                        $menu_active = 'active'; 
                    }
                    $html .= '<li class="'.$menu_active.'">';
                    $html .= anchor('menu/'.$data['url'], $data['text']);
                    $html .='</li>';
                }
                $html .= '</ul>';
                return $html;
            }
    }

?>